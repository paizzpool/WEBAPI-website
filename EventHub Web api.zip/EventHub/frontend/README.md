# EventHub

Plain HTML, CSS and JavaScript frontend + PHP/MySQL API. Served by XAMPP Apache.

## Run (XAMPP)
1. In the XAMPP Control Panel start **Apache** and **MySQL**.
2. Import `eventhub_new.sql` into database `eventhub_db` if the database is empty.
3. Open http://localhost/EventHub/frontend/ in the browser.
4. Register a new account, or sign in with `admin@eventhub.com` / `Password123`.

The folders `backend/data/` and `backend/config/` must be writable by Apache (default on XAMPP):
the JWT secret, rate-limit counters and revoked tokens are stored there.

## Pages
- `index.html`: login + register
- `dashboard.html`: shown after login (Overview, Events, Bookings, Users (admin only), My account)

## Who can do what

| Action | Admin | Organiser | Customer |
|---|---|---|---|
| View events | yes | yes | yes |
| Add event | yes (picks the organiser) | yes (own account) | no |
| Edit / delete event | yes | no | no |
| Change booking status (pending / confirmed / cancelled) | all bookings | bookings on own events | no |
| Book + demo payment | no | no | yes |

The rules are enforced in the PHP API (`events.php`, `bookings.php`), not just hidden in the dashboard.

## Frontend files
- `js/config.js`: API address
- `js/api.js`: JWT storage + `api()` fetch wrapper (adds `Authorization: Bearer <token>`)
- `js/auth.js`: login / register page
- `js/dashboard.js`: dashboard views

## Security and API management (backend)

| Feature | Where | How it works |
|---|---|---|
| **JWT (HS256)** | `api/jwt.php`, `api/auth.php`, `api/login.php` | Login returns a signed token (1 h). Every request sends `Authorization: Bearer <token>`. Signature, issuer, expiry and revocation are checked. `alg: none` and forged tokens are rejected. |
| **Logout / revoke** | `api/logout.php` | Token ID (`jti`) goes on a revocation list, so a stolen token stops working. |
| **API key** | `api/api_key.php` | Public read endpoints (`events`, `venues`, `reviews`, `venue_location`) need a JWT **or** `X-API-Key`. Keys: `EVENTHUB_API_KEYS` env var (comma separated). Demo key: `eventhub-demo-key-change-me` (change it). |
| **Rate limiting** | `api/rate_limit.php`, `config/security.php` | Login: 20 attempts / 5 min per IP and 5 failed / 5 min per email+IP. Register: 5 / 10 min per IP. All API calls: 120 / min per user. Returns `429` with `Retry-After`. |
| **Pagination, search, sort** | `api/pagination.php`, `users.php`, `events.php` | `?page=1&limit=10&search=...&sort=name&order=desc` (+ `role=` on users). Response has a `pagination` object. Sort columns are whitelisted; `limit` max 100. |
| **Dashboard numbers** | `api/stats.php` | Role-aware totals (admin: all, organiser: own events, customer: own bookings). |

Example (API key client):

    curl -H "X-API-Key: eventhub-demo-key-change-me" \
      "http://localhost/EventHub/backend/api/events.php?page=1&limit=5&sort=ticket_price&order=desc"

Optional production settings (environment variables): `EVENTHUB_JWT_SECRET` (32+ chars), `EVENTHUB_API_KEYS`.
If not set, a random JWT secret is created once in `backend/config/jwt_secret.key` (git-ignored).

## API
- POST `/EventHub/backend/api/login.php` returns `token`
- POST `/EventHub/backend/api/register.php`
- POST `/EventHub/backend/api/logout.php`
- GET  `/EventHub/backend/api/me.php`
- GET  `/EventHub/backend/api/stats.php`
- GET  `/EventHub/backend/api/users.php` (admin) with page / limit / search / role / sort / order
- GET  `/EventHub/backend/api/events.php` with page / limit / search / sort / order
