(() => {
  // No valid JWT -> back to login.
  if (!Auth.valid()) { Auth.clear(); return location.replace('index.html?expired=1'); }

  const $ = (id) => document.getElementById(id);
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = (n) => 'RM ' + Number(n || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const dateFmt = (d, o = { day: 'numeric', month: 'short', year: 'numeric' }) => (d ? new Date(String(d).replace(' ', 'T')).toLocaleDateString(undefined, o) : '-');
  const timeFmt = (d) => new Date(String(d).replace(' ', 'T')).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
  const debounce = (fn, ms = 300) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

  let me = null;
  let venues = {};          // venue_id -> name
  let currentView = null;
  const loaded = {};

  const banner = (msg) => { const b = $('dashBanner'); b.hidden = !msg; b.textContent = msg || ''; };
  const fail = (err) => banner(err.message || 'Something went wrong.');

  /* ---------- sign out (revokes the JWT server-side) ---------- */
  async function logout(message) {
    try { await api('/logout.php', { method: 'POST' }); } catch { /* clear locally anyway */ }
    Auth.clear();
    location.replace('index.html' + (message ? '?expired=1' : ''));
  }
  $('logout').addEventListener('click', () => logout());

  /* ---------- session countdown ---------- */
  function tickSession() {
    const left = Auth.secondsLeft();
    if (left <= 0) { Auth.clear(); return location.replace('index.html?expired=1'); }
    const m = String(Math.floor(left / 60)).padStart(2, '0'), s = String(left % 60).padStart(2, '0');
    $('sessionTime').textContent = m + ':' + s;
    $('sessionChip').classList.toggle('warn', left <= 300 && left > 60);
    $('sessionChip').classList.toggle('danger', left <= 60);
    if ($('tLeft')) $('tLeft').textContent = m + ':' + s;
  }
  setInterval(tickSession, 1000);
  tickSession();

  /* ---------- reusable pager ---------- */
  function renderPager(el, { page, total_pages, total, limit }, onPage) {
    if (!total) { el.innerHTML = ''; return; }
    const from = (page - 1) * limit + 1, to = Math.min(page * limit, total);
    const nums = [];
    for (let i = 1; i <= total_pages; i++) if (i === 1 || i === total_pages || Math.abs(i - page) <= 1) nums.push(i);
    let html = '', prev = 0;
    nums.forEach((n) => { if (n - prev > 1) html += '<span class="gap">…</span>'; html += `<button data-p="${n}" class="${n === page ? 'is-on' : ''}">${n}</button>`; prev = n; });
    el.innerHTML = `<span>Showing ${from}–${to} of ${total}</span>
      <div class="pages"><button data-p="${page - 1}" ${page <= 1 ? 'disabled' : ''}>Prev</button>${html}<button data-p="${page + 1}" ${page >= total_pages ? 'disabled' : ''}>Next</button></div>`;
    el.querySelectorAll('button[data-p]').forEach((b) => b.addEventListener('click', () => onPage(+b.dataset.p)));
  }

  /* ================= OVERVIEW ================= */
  async function loadOverview() {
    const { data: s } = await api('/stats.php');
    const first = me.name.split(' ')[0];
    const hour = new Date().getHours();
    $('greeting').textContent = (hour < 12 ? 'Good morning, ' : hour < 18 ? 'Good afternoon, ' : 'Good evening, ') + first;
    $('greetingSub').textContent = { admin: 'Platform-wide numbers across EventHub.', organiser: 'How your events are performing.', customer: 'Your bookings and what is coming up.' }[s.role];

    const cards = s.role === 'customer'
      ? [['My bookings', s.bookings_total, 'all statuses', '--teal'], ['Tickets confirmed', s.tickets_sold, 'confirmed bookings', '--ok'], ['Total spent', money(s.revenue), 'confirmed only', '--gold'], ['Events to explore', s.events_total, 'upcoming on EventHub', '--teal-soft']]
      : [['Revenue', money(s.revenue), 'confirmed bookings', '--gold'], ['Tickets sold', s.tickets_sold, 'confirmed bookings', '--ok'], ['Bookings', s.bookings_total, 'all statuses', '--teal'],
         s.role === 'admin' ? ['Users', s.users_total, `${s.venues_total} venues · ${s.events_total} events`, '--teal-soft'] : ['My events', s.events_total, `${s.events_upcoming} upcoming`, '--teal-soft']];
    if (s.average_rating != null) cards.push(['Average rating', s.average_rating + ' / 5', 'from reviews', '--gold']);
    $('statCards').innerHTML = cards.map(([l, v, n, c], i) => `<div class="stat" style="--accent:var(${c});animation-delay:${i * 60}ms"><small>${esc(l)}</small><b>${esc(v)}</b><span>${esc(n)}</span></div>`).join('');

    // bookings by status
    const st = s.bookings_by_status, tot = (st.confirmed + st.pending + st.cancelled) || 1;
    $('statusBars').innerHTML = `<div class="stack">${['confirmed', 'pending', 'cancelled'].map((k) => `<i class="c-${k}" style="width:${(st[k] / tot) * 100}%"></i>`).join('')}</div>
      <div class="legend">${['confirmed', 'pending', 'cancelled'].map((k) => `<div><em class="c-${k}"></em>${k[0].toUpperCase() + k.slice(1)}<b style="margin-left:auto">${st[k]}</b><span style="margin-left:6px">${Math.round((st[k] / tot) * 100)}%</span></div>`).join('')}</div>`;

    // upcoming
    $('upcomingTitle').textContent = s.role === 'customer' ? 'Your upcoming events' : 'Upcoming events';
    $('upcomingList').innerHTML = s.upcoming_events.length
      ? `<div class="rows">${s.upcoming_events.map((e) => {
          const d = new Date(e.event_date.replace(' ', 'T'));
          const meta = e.total_tickets ? `<div class="meter"><i style="width:${((e.total_tickets - e.tickets_available) / e.total_tickets) * 100}%"></i></div>` : '';
          return `<div class="row"><div class="datebox"><b>${d.getDate()}</b><small>${d.toLocaleDateString(undefined, { month: 'short' })}</small></div>
            <div class="grow"><b>${esc(e.event_name)}</b><small>${esc(e.venue_name)} · ${timeFmt(e.event_date)}</small>${meta}</div>
            <div class="end">${e.quantity ? e.quantity + ' ticket' + (e.quantity > 1 ? 's' : '') : e.tickets_available + ' left'}</div></div>`;
        }).join('')}</div>`
      : '<p class="empty">Nothing coming up.</p>';

    // recent bookings
    $('recentBookings').innerHTML = s.recent_bookings.length
      ? `<div class="rows">${s.recent_bookings.map((b) => `<div class="row"><div class="grow"><b>${esc(b.event_name)}</b><small>${esc(b.customer_name)} · ${dateFmt(b.booked_at)}</small></div>
          <div class="end">${b.quantity} × <span class="badge ${esc(b.booking_status)}">${esc(b.booking_status)}</span></div></div>`).join('')}</div>`
      : '<p class="empty">No bookings yet.</p>';

    // top events (not for customers)
    $('topCard').hidden = s.role === 'customer';
    if (s.top_events) {
      $('topEvents').innerHTML = s.top_events.length
        ? `<div class="rows">${s.top_events.map((e) => `<div class="row"><div class="grow"><b>${esc(e.event_name)}</b>
            <div class="meter"><i style="width:${e.total_tickets ? (e.tickets_booked / e.total_tickets) * 100 : 0}%"></i></div></div>
            <div class="end">${e.tickets_booked} / ${e.total_tickets}</div></div>`).join('')}</div>`
        : '<p class="empty">No events yet.</p>';
    }
  }

  /* ================= EVENTS (server-side search / sort / pagination) ================= */
  const ev = { page: 1, limit: 10, sort: 'event_date', order: 'asc', search: '', byId: {} };
  async function loadEvents() {
    const t = $('evTable'); t.classList.add('loading');
    const canBook = me.role === 'customer';
    const isAdmin = me.role === 'admin';
    try {
      const r = await api('/events.php', { query: { page: ev.page, limit: ev.limit, sort: ev.sort, order: ev.order, search: ev.search } });
      r.data.forEach((x) => { ev.byId[x.event_id] = x; bk.events[x.event_id] = x; });
      const cols = (canBook || isAdmin) ? 6 : 5;
      t.innerHTML = `<thead><tr><th>Event</th><th>Date</th><th>Venue</th><th class="num">Price</th><th style="min-width:150px">Availability</th>${(canBook || isAdmin) ? '<th></th>' : ''}</tr></thead><tbody>${
        r.data.length ? r.data.map((e) => {
          const sold = e.total_tickets - e.tickets_available, pct = e.total_tickets ? (sold / e.total_tickets) * 100 : 0;
          const soldOut = Number(e.tickets_available) < 1;
          return `<tr><td><b>${esc(e.event_name)}</b><small>${esc((e.description || '').slice(0, 70))}${(e.description || '').length > 70 ? '…' : ''}</small></td>
            <td>${dateFmt(e.event_date)}<small>${timeFmt(e.event_date)}</small></td><td>${esc(venues[e.venue_id] || 'Venue #' + e.venue_id)}</td>
            <td class="num">${money(e.ticket_price)}</td>
            <td>${e.tickets_available} left<small>of ${e.total_tickets}</small><div class="meter"><i style="width:${pct}%"></i></div></td>
            ${canBook ? `<td><button class="btn-book" type="button" data-book="${e.event_id}" ${soldOut ? 'disabled' : ''}>${soldOut ? 'Sold out' : 'Book'}</button></td>` : ''}
            ${isAdmin ? `<td><div class="row-actions"><button class="btn-mini" type="button" data-edit="${e.event_id}">Edit</button><button class="btn-mini danger" type="button" data-del="${e.event_id}">Delete</button></div></td>` : ''}</tr>`;
        }).join('') : `<tr><td colspan="${cols}"><p class="empty" style="text-align:center">No events match “${esc(ev.search)}”.</p></td></tr>`}</tbody>`;
      t.querySelectorAll('[data-edit]').forEach((b) => b.addEventListener('click', () => openEventForm(ev.byId[+b.dataset.edit])));
      t.querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', () => deleteEvent(ev.byId[+b.dataset.del])));
      t.querySelectorAll('[data-book]').forEach((b) => b.addEventListener('click', () => openCheckout(ev.byId[+b.dataset.book])));
      renderPager($('evPager'), r.pagination, (p) => { ev.page = p; loadEvents(); });
      banner('');
    } catch (e) { fail(e); } finally { t.classList.remove('loading'); }
  }
  $('evSearch').addEventListener('input', debounce((e) => { ev.search = e.target.value.trim(); ev.page = 1; loadEvents(); }));
  $('evSort').addEventListener('change', (e) => { ev.sort = e.target.value; ev.page = 1; loadEvents(); });
  $('evLimit').addEventListener('change', (e) => { ev.limit = +e.target.value; ev.page = 1; loadEvents(); });
  $('evOrder').addEventListener('click', (e) => { ev.order = ev.order === 'asc' ? 'desc' : 'asc'; e.target.textContent = ev.order === 'asc' ? 'Asc' : 'Desc'; ev.page = 1; loadEvents(); });


  /* ================= ADD / EDIT EVENT (admin: add + edit + delete, organiser: add only) ================= */
  const form = { editing: null, organisersLoaded: false };
  const pad = (n) => String(n).padStart(2, '0');
  const toInputDate = (sql) => String(sql || '').replace(' ', 'T').slice(0, 16);
  const toSqlDate = (v) => (v.length === 16 ? v + ':00' : v).replace('T', ' ');

  async function fillFormLists(selectedVenue, selectedOrganiser) {
    $('fVenue').innerHTML = Object.entries(venues).map(([id, name]) => `<option value="${id}">${esc(name)}</option>`).join('')
      || '<option value="">No venues yet</option>';
    if (selectedVenue) $('fVenue').value = String(selectedVenue);
    if (me.role === 'admin') {
      if (!form.organisersLoaded) {
        const r = await api('/users.php', { query: { role: 'organiser', limit: 100 } });
        $('fOrganiser').innerHTML = r.data.map((u) => `<option value="${u.user_id}">${esc(u.name)} (${esc(u.email)})</option>`).join('');
        form.organisersLoaded = true;
      }
      if (selectedOrganiser) $('fOrganiser').value = String(selectedOrganiser);
    }
  }

  async function openEventForm(event) {
    if (me.role === 'customer') return;
    if (event && me.role !== 'admin') return;          // organisers can only create
    form.editing = event || null;
    $('evFormError').hidden = true;
    $('evFormTitle').textContent = event ? 'Edit event' : 'Add event';
    $('evFormSub').textContent = event
      ? 'Changes are saved straight to the database.'
      : (me.role === 'organiser' ? 'The event will be created under your account.' : 'Create an event and choose its organiser.');
    $('fOrganiserField').hidden = me.role !== 'admin';
    try { await fillFormLists(event?.venue_id, event?.organiser_id); } catch (e) { return fail(e); }
    $('fName').value = event?.event_name || '';
    $('fDesc').value = event?.description || '';
    $('fDate').value = event ? toInputDate(event.event_date) : '';
    $('fPrice').value = event ? Number(event.ticket_price).toFixed(2) : '';
    $('fTotal').value = event ? event.total_tickets : '';
    const sold = event ? event.total_tickets - event.tickets_available : 0;
    $('fTotal').min = Math.max(1, sold);
    $('fTotalHint').textContent = event ? `${sold} ticket${sold === 1 ? '' : 's'} already booked. Available tickets update automatically.` : 'All tickets start as available.';
    $('eventModal').hidden = false;
    $('fName').focus();
  }
  const closeEventForm = () => { $('eventModal').hidden = true; form.editing = null; $('evFormSave').classList.remove('loading'); };

  $('evAdd').addEventListener('click', () => openEventForm(null));
  $('evFormCancel').addEventListener('click', closeEventForm);
  $('eventModal').addEventListener('click', (e) => { if (e.target === $('eventModal')) closeEventForm(); });

  $('evFormSave').addEventListener('click', async () => {
    const err = $('evFormError'); err.hidden = true;
    const body = {
      event_name: $('fName').value.trim(),
      description: $('fDesc').value.trim() || null,
      venue_id: +$('fVenue').value,
      event_date: toSqlDate($('fDate').value),
      ticket_price: $('fPrice').value,
      total_tickets: +$('fTotal').value,
    };
    if (me.role === 'admin') body.organiser_id = +$('fOrganiser').value;
    const problem = !body.event_name ? 'Enter the event name.'
      : !body.venue_id ? 'Choose a venue.'
      : !$('fDate').value ? 'Choose the date and time.'
      : ($('fPrice').value === '' || +$('fPrice').value < 0) ? 'Enter a ticket price (0 or more).'
      : !(body.total_tickets >= 1) ? 'Total tickets must be at least 1.'
      : (me.role === 'admin' && !body.organiser_id) ? 'Choose an organiser.' : '';
    if (problem) { err.textContent = problem; err.hidden = false; return; }

    const btn = $('evFormSave'); btn.classList.add('loading');
    try {
      if (form.editing) await api('/events.php', { method: 'PUT', query: { id: form.editing.event_id }, body });
      else await api('/events.php', { method: 'POST', body });
      closeEventForm();
      ev.page = 1;
      loaded.bookingLookups = false;
      await loadEvents();
      banner('');
    } catch (e) {
      err.textContent = e.data?.errors?.map?.((x) => x.message).join(', ') || e.message || 'Could not save the event.';
      err.hidden = false;
    } finally { btn.classList.remove('loading'); }
  });

  async function deleteEvent(event) {
    if (me.role !== 'admin' || !event) return;
    if (!confirm(`Delete "${event.event_name}"? This cannot be undone.`)) return;
    try {
      await api('/events.php', { method: 'DELETE', query: { id: event.event_id } });
      loaded.bookingLookups = false;
      await loadEvents();
    } catch (e) { fail(e); }
  }

  /* ================= CUSTOMER CHECKOUT (demo payment) ================= */
  const checkout = { event: null, qty: 1 };
  function maxQty() { return Math.max(1, Number(checkout.event?.tickets_available) || 1); }
  function setQty(n) {
    const max = maxQty();
    checkout.qty = Math.min(max, Math.max(1, n | 0));
    $('bookQty').value = checkout.qty;
    $('bookTotal').textContent = money((checkout.event?.ticket_price || 0) * checkout.qty);
  }
  function closeCheckout() {
    $('bookModal').hidden = true;
    checkout.event = null;
    $('bookPay').classList.remove('loading');
  }
  function openCheckout(event) {
    if (!event || me.role !== 'customer') return;
    if (Number(event.tickets_available) < 1) return banner('This event is sold out.');
    checkout.event = event;
    $('bookCheckout').hidden = false;
    $('bookDone').hidden = true;
    $('bookError').hidden = true;
    $('bookTitle').textContent = event.event_name;
    $('bookEventMeta').textContent = `${venues[event.venue_id] || 'Venue'} · ${dateFmt(event.event_date)} · ${timeFmt(event.event_date)}`;
    $('bookUnit').textContent = money(event.ticket_price);
    $('bookLeft').textContent = event.tickets_available + ' ticket' + (event.tickets_available === 1 ? '' : 's') + ' left';
    $('payName').value = me.name || '';
    $('payCard').value = '';
    $('payExp').value = '';
    $('payCvv').value = '';
    setQty(1);
    $('bookModal').hidden = false;
  }
  $('qtyMinus').addEventListener('click', () => setQty(checkout.qty - 1));
  $('qtyPlus').addEventListener('click', () => setQty(checkout.qty + 1));
  $('bookQty').addEventListener('input', (e) => setQty(+e.target.value || 1));
  $('bookCancel').addEventListener('click', closeCheckout);
  $('bookModal').addEventListener('click', (e) => { if (e.target === $('bookModal')) closeCheckout(); });
  $('payCard').addEventListener('input', (e) => {
    const digits = e.target.value.replace(/\D/g, '').slice(0, 16);
    e.target.value = digits.replace(/(\d{4})(?=\d)/g, '$1 ');
  });
  $('payExp').addEventListener('input', (e) => {
    let v = e.target.value.replace(/\D/g, '').slice(0, 4);
    if (v.length > 2) v = v.slice(0, 2) + '/' + v.slice(2);
    e.target.value = v;
  });
  $('bookPay').addEventListener('click', async () => {
    const err = $('bookError');
    err.hidden = true;
    if (!checkout.event) return;
    if (!$('payName').value.trim() || $('payCard').value.replace(/\D/g, '').length < 16 || !/^\d{2}\/\d{2}$/.test($('payExp').value) || $('payCvv').value.replace(/\D/g, '').length < 3) {
      err.textContent = 'Fill in the demo card details to continue.';
      err.hidden = false;
      return;
    }
    const btn = $('bookPay');
    btn.classList.add('loading');
    try {
      const res = await api('/bookings.php', {
        method: 'POST',
        body: {
          customer_id: me.user_id,
          event_id: checkout.event.event_id,
          quantity: checkout.qty,
          booking_status: 'confirmed',
        },
      });
      const b = res.data;
      const eventName = checkout.event.event_name;
      const qty = checkout.qty;
      const total = money((checkout.event.ticket_price || 0) * qty);
      checkout.event.tickets_available = Math.max(0, Number(checkout.event.tickets_available) - qty);
      loaded.bookingLookups = false;
      $('bookCheckout').hidden = true;
      $('bookDone').hidden = false;
      $('bookDoneMsg').textContent = 'Payment received. Your tickets are confirmed.';
      $('bookDoneFacts').innerHTML = `<dt>Booking</dt><dd>#${b.booking_id}</dd>
        <dt>Event</dt><dd>${esc(eventName)}</dd>
        <dt>Tickets</dt><dd>${qty}</dd>
        <dt>Paid</dt><dd>${total}</dd>
        <dt>Status</dt><dd><span class="badge confirmed">confirmed</span></dd>`;
    } catch (e) {
      err.textContent = e.message || 'Payment could not be completed.';
      err.hidden = false;
    } finally {
      btn.classList.remove('loading');
    }
  });
  $('bookView').addEventListener('click', () => {
    closeCheckout();
    location.hash = 'bookings';
  });

  /* ================= BOOKINGS (role-scoped list, paged in the browser) ================= */
  const bk = { all: [], status: '', page: 1, limit: 8, events: {}, users: {} };
  async function loadBookings() {
    const t = $('bkTable'); t.classList.add('loading');
    try {
      if (!loaded.bookingLookups) {
        const e = await api('/events.php', { query: { limit: 100 } });
        e.data.forEach((x) => { bk.events[x.event_id] = x; });
        if (me.role === 'admin') {
          const u = await api('/users.php', { query: { limit: 100 } });
          u.data.forEach((x) => { bk.users[x.user_id] = x.name; });
        }
        loaded.bookingLookups = true;
      }
      bk.all = (await api('/bookings.php')).data.sort((a, b) => b.booked_at.localeCompare(a.booked_at));
      renderBookings();
      banner('');
    } catch (e) { fail(e); } finally { t.classList.remove('loading'); }
  }
  function renderBookings() {
    const rows = bk.all.filter((b) => !bk.status || b.booking_status === bk.status);
    const total_pages = Math.max(1, Math.ceil(rows.length / bk.limit));
    bk.page = Math.min(bk.page, total_pages);
    const slice = rows.slice((bk.page - 1) * bk.limit, bk.page * bk.limit);
    const showCustomer = me.role !== 'customer';
    const canManage = me.role === 'admin' || me.role === 'organiser';
    const statusCell = (b) => {
      if (!canManage) return `<span class="badge ${esc(b.booking_status)}">${esc(b.booking_status)}</span>`;
      const locked = me.role === 'organiser' && b.booking_status === 'cancelled';   // organisers cannot revive a cancelled booking
      return `<select class="status-select" data-bk="${b.booking_id}" ${locked ? 'disabled title="Cancelled bookings can only be reopened by an admin"' : ''}>${
        ['pending', 'confirmed', 'cancelled'].map((k) => `<option value="${k}" ${k === b.booking_status ? 'selected' : ''}>${k}</option>`).join('')}</select>`;
    };
    $('bkTable').innerHTML = `<thead><tr><th>#</th><th>Event</th>${showCustomer ? '<th>Customer</th>' : ''}<th class="num">Tickets</th><th class="num">Total</th><th>Status</th><th>Booked</th></tr></thead><tbody>${
      slice.length ? slice.map((b) => {
        const e = bk.events[b.event_id];
        return `<tr><td>${b.booking_id}</td><td><b>${esc(e ? e.event_name : 'Event #' + b.event_id)}</b></td>
          ${showCustomer ? `<td>${esc(bk.users[b.customer_id] || 'Customer #' + b.customer_id)}</td>` : ''}
          <td class="num">${b.quantity}</td><td class="num">${e ? money(e.ticket_price * b.quantity) : '-'}</td>
          <td>${statusCell(b)}</td><td>${dateFmt(b.booked_at)}</td></tr>`;
      }).join('') : `<tr><td colspan="7"><p class="empty" style="text-align:center">No bookings to show.</p></td></tr>`}</tbody>`;
    $('bkTable').querySelectorAll('select[data-bk]').forEach((sel) => sel.addEventListener('change', () => changeBookingStatus(+sel.dataset.bk, sel.value)));
    renderPager($('bkPager'), { page: bk.page, total_pages, total: rows.length, limit: bk.limit }, (p) => { bk.page = p; renderBookings(); });
  }
  // Admin + organiser: change a booking's status (the server also checks the role and ownership).
  async function changeBookingStatus(id, status) {
    const b = bk.all.find((x) => x.booking_id === id);
    if (!b) return;
    try {
      await api('/bookings.php', { method: 'PUT', query: { id }, body: { customer_id: b.customer_id, event_id: b.event_id, quantity: b.quantity, booking_status: status } });
      loaded.bookingLookups = false;
      await loadBookings();
    } catch (e) { fail(e); renderBookings(); }   // put the dropdown back to the real value
  }
  $('bkChips').addEventListener('click', (e) => {
    const c = e.target.closest('.chip'); if (!c) return;
    $('bkChips').querySelectorAll('.chip').forEach((x) => x.classList.toggle('is-on', x === c));
    bk.status = c.dataset.status; bk.page = 1; renderBookings();
  });

  /* ================= USERS (admin: server-side search / filter / sort / pagination) ================= */
  const us = { page: 1, limit: 10, sort: 'user_id', order: 'asc', search: '', role: '' };
  const usCols = [['user_id', '#'], ['name', 'Name'], ['email', 'Email'], ['role', 'Role'], ['created_at', 'Joined']];
  async function loadUsers() {
    const t = $('usTable'); t.classList.add('loading');
    try {
      const r = await api('/users.php', { query: { page: us.page, limit: us.limit, sort: us.sort, order: us.order, search: us.search, role: us.role } });
      const head = usCols.map(([k, l]) => `<th data-sort="${k}">${l}${us.sort === k ? `<span class="arrow">${us.order === 'asc' ? '▲' : '▼'}</span>` : ''}</th>`).join('');
      t.innerHTML = `<thead><tr>${head}</tr></thead><tbody>${
        r.data.length ? r.data.map((u) => `<tr><td>${u.user_id}</td><td><b>${esc(u.name)}</b></td><td>${esc(u.email)}</td>
          <td><span class="badge ${esc(u.role)}">${esc(u.role)}</span></td><td>${dateFmt(u.created_at)}</td></tr>`).join('')
        : `<tr><td colspan="5"><p class="empty" style="text-align:center">No users match your filters.</p></td></tr>`}</tbody>`;
      t.querySelectorAll('th[data-sort]').forEach((th) => th.addEventListener('click', () => {
        const k = th.dataset.sort;
        us.order = us.sort === k && us.order === 'asc' ? 'desc' : 'asc'; us.sort = k; us.page = 1; loadUsers();
      }));
      renderPager($('usPager'), r.pagination, (p) => { us.page = p; loadUsers(); });
      banner('');
    } catch (e) { fail(e); } finally { t.classList.remove('loading'); }
  }
  $('usSearch').addEventListener('input', debounce((e) => { us.search = e.target.value.trim(); us.page = 1; loadUsers(); }));
  $('usRole').addEventListener('change', (e) => { us.role = e.target.value; us.page = 1; loadUsers(); });
  $('usLimit').addEventListener('change', (e) => { us.limit = +e.target.value; us.page = 1; loadUsers(); });

  /* ================= PROFILE ================= */
  async function loadProfile() {
    const u = (await api('/me.php')).data, c = Auth.claims() || {};
    $('pName').textContent = u.name; $('pEmail').textContent = u.email; $('pRole').textContent = u.role;
    $('pSince').textContent = dateFmt(u.created_at, { year: 'numeric', month: 'long', day: 'numeric' });
    const full = { dateStyle: 'medium', timeStyle: 'medium' };
    $('tIssued').textContent = c.iat ? new Date(c.iat * 1000).toLocaleString(undefined, full) : '-';
    $('tExpires').textContent = c.exp ? new Date(c.exp * 1000).toLocaleString(undefined, full) : '-';
    $('tJti').textContent = c.jti ? c.jti.slice(0, 8) + '…' + c.jti.slice(-4) : '-';
    tickSession();
  }

  /* ================= router ================= */
  const views = {
    overview: ['Overview', loadOverview],
    events: ['Events', loadEvents],
    bookings: ['Bookings', loadBookings],
    users: ['Users', loadUsers],
    profile: ['My account', loadProfile],
  };

  async function show(name) {
    if (!views[name] || (name === 'users' && me.role !== 'admin')) name = 'overview';
    currentView = name;
    document.querySelectorAll('.view-pane').forEach((p) => { p.hidden = p.id !== 'view-' + name; });
    document.querySelectorAll('.nav-item[data-view]').forEach((n) => n.classList.toggle('is-active', n.dataset.view === name));
    $('pageTitle').textContent = views[name][0];
    closeMenu();
    banner('');
    try { await views[name][1](); } catch (e) { fail(e); }
  }
  document.querySelectorAll('.nav-item[data-view]').forEach((n) => n.addEventListener('click', () => { location.hash = n.dataset.view; }));
  window.addEventListener('hashchange', () => show(location.hash.slice(1)));

  /* mobile drawer */
  const closeMenu = () => { $('sidebar').classList.remove('open'); $('scrim').classList.remove('open'); };
  $('menuBtn').addEventListener('click', () => { $('sidebar').classList.add('open'); $('scrim').classList.add('open'); });
  $('scrim').addEventListener('click', closeMenu);

  /* ================= boot ================= */
  (async () => {
    try {
      me = (await api('/me.php')).data;
      $('chipName').textContent = me.name;
      $('chipRole').textContent = me.role;
      $('avatar').textContent = me.name.split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase();
      document.querySelectorAll('[data-role]').forEach((n) => { n.hidden = n.dataset.role !== me.role; });
      document.querySelectorAll('[data-roles]').forEach((n) => { n.hidden = !n.dataset.roles.split(' ').includes(me.role); });

      try { (await api('/venues.php')).data.forEach((v) => { venues[v.venue_id] = v.venue_name; }); } catch { /* names fall back to ids */ }
      show(location.hash.slice(1) || 'overview');
    } catch (e) {
      $('greeting').textContent = 'Something went wrong';
      fail(e);
      document.querySelector('#view-overview').hidden = false;
    }
  })();
})();
