// Shared helpers: JWT storage + fetch wrapper that sends "Authorization: Bearer <token>".
// Loaded after config.js on every page.

const Auth = {
  get token() { return localStorage.getItem('token'); },
  get user() {
    try { return JSON.parse(localStorage.getItem('user') || 'null'); } catch { return null; }
  },
  save(token, user) {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
  },
  clear() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  },
  // Decode (NOT verify) the token payload so the UI can show expiry. The server does the real check.
  claims() {
    try {
      const part = (this.token || '').split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
      return JSON.parse(atob(part + '='.repeat((4 - (part.length % 4)) % 4)));
    } catch { return null; }
  },
  secondsLeft() {
    const c = this.claims();
    return c && c.exp ? c.exp - Math.floor(Date.now() / 1000) : 0;
  },
  valid() { return !!this.token && this.secondsLeft() > 0; },
};

class ApiError extends Error {
  constructor(message, status = 0, data = {}) {
    super(message);
    this.status = status;
    this.data = data;
  }
}

async function api(path, { method = 'GET', body, query } = {}) {
  let url = API_BASE + path;
  if (query) {
    const qs = new URLSearchParams();
    Object.entries(query).forEach(([k, v]) => { if (v !== '' && v != null) qs.set(k, v); });
    if ([...qs].length) url += '?' + qs;
  }

  const headers = {};
  if (body) headers['Content-Type'] = 'application/json';
  if (Auth.token) headers['Authorization'] = 'Bearer ' + Auth.token;

  let res;
  try {
    res = await fetch(url, { method, headers, body: body ? JSON.stringify(body) : undefined });
  } catch {
    throw new ApiError("Can't reach the server. Start Apache and MySQL in XAMPP, then open this page from http://localhost/EventHub/frontend/");
  }

  const data = await res.json().catch(() => ({}));

  if (res.status === 401 && Auth.token) {
    // Token expired / revoked / invalid: back to the login page.
    Auth.clear();
    location.replace('index.html?expired=1');
    throw new ApiError(data.message || 'Session expired', 401, data);
  }
  if (!res.ok) throw new ApiError(data.message || 'Request failed (' + res.status + ')', res.status, data);
  return data;
}
