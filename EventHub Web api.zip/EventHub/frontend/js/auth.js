(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  // Already logged in with a still-valid JWT? Skip the login page.
  if (Auth.valid()) location.replace('dashboard.html');
  else Auth.clear();

  /* ---------- floating background dots ---------- */
  const dotsBox = $('#dots');
  for (let i = 0; i < 16; i++) {
    const d = document.createElement('span');
    const size = Math.random() < .5 ? 8 + Math.random() * 6 : 4 + Math.random() * 4;
    d.className = 'dot ' + (Math.random() < .45 ? 'fill' : 'ring');
    Object.assign(d.style, {
      width: size + 'px', height: size + 'px',
      left: Math.random() * 100 + '%', top: Math.random() * 100 + '%',
    });
    d.style.setProperty('--dx', (Math.random() * 90 - 45) + 'px');
    d.style.setProperty('--dy', (Math.random() * 90 - 45) + 'px');
    d.style.setProperty('--dur', (7 + Math.random() * 9) + 's');
    d.style.setProperty('--delay', (-Math.random() * 10) + 's');
    dotsBox.appendChild(d);
  }

  /* ---------- icons ---------- */
  const EYE = '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>';
  const EYE_OFF = '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.9 17.9A10.9 10.9 0 0 1 12 19C5 19 1 12 1 12a18.5 18.5 0 0 1 5.1-5.9M9.9 5.1A10.4 10.4 0 0 1 12 5c7 0 11 7 11 7a18.5 18.5 0 0 1-2.2 3.2M1 1l22 22"/></svg>';

  $$('.eye').forEach((btn) => {
    btn.innerHTML = EYE;
    btn.addEventListener('click', () => {
      const input = btn.parentElement.querySelector('input');
      const show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.innerHTML = show ? EYE_OFF : EYE;
      btn.setAttribute('aria-pressed', String(show));
      btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    });
  });

  /* ---------- clear-email button ---------- */
  const loginEmail = $('#loginEmail');
  const clearBtn = $('.clear');
  loginEmail.addEventListener('input', () => { clearBtn.hidden = !loginEmail.value; });
  clearBtn.addEventListener('click', () => { loginEmail.value = ''; clearBtn.hidden = true; loginEmail.focus(); });

  /* ---------- switch between login / register ---------- */
  const panel = $('#panel');
  const views = { login: $('#loginForm'), register: $('#registerForm') };
  let current = 'login';

  function go(name) {
    if (name === current) return;
    const from = views[current], to = views[name];
    const startH = panel.offsetHeight;
    panel.style.height = startH + 'px';
    from.classList.remove('is-active');
    to.classList.toggle('from-left', name === 'login');
    to.classList.add('is-active');
    const endH = to.offsetHeight;
    requestAnimationFrame(() => { panel.style.height = endH + 'px'; });
    panel.addEventListener('transitionend', () => { panel.style.height = ''; }, { once: true });
    current = name;
    to.querySelector('input')?.focus({ preventScroll: true });
  }
  $$('[data-go]').forEach((b) => b.addEventListener('click', () => go(b.dataset.go)));

  /* ---------- validation (mirrors the backend rules) ---------- */
  const rules = {
    name: (v) => (v.trim().length < 2 ? 'Enter your name (at least 2 characters).' : ''),
    email: (v) => (!v.trim() ? 'Enter your email address.' : !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()) ? 'Enter a valid email address, like name@example.com.' : ''),
    registerPassword: (v) => (v.length < 8 ? 'Password needs at least 8 characters.' : !/[A-Z]/.test(v) ? 'Add an uppercase letter.' : !/[a-z]/.test(v) ? 'Add a lowercase letter.' : !/[0-9]/.test(v) ? 'Add a number.' : ''),
    loginPassword: (v) => (!v ? 'Enter your password.' : ''),
  };

  function setError(input, msg) {
    const field = input.closest('.field');
    field.classList.toggle('invalid', !!msg);
    field.classList.toggle('valid', !msg && !!input.value);
    field.querySelector('.error-text').textContent = msg || '';
    input.setAttribute('aria-invalid', msg ? 'true' : 'false');
  }
  function check(input, formName) {
    const key = input.name === 'password' ? (formName === 'register' ? 'registerPassword' : 'loginPassword') : input.name;
    const msg = rules[key](input.value);
    setError(input, msg);
    return !msg;
  }
  Object.entries(views).forEach(([formName, form]) => {
    $$('input', form).forEach((input) => {
      input.addEventListener('blur', () => { if (input.value || input.closest('.field').classList.contains('invalid')) check(input, formName); });
      input.addEventListener('input', () => { if (input.closest('.field').classList.contains('invalid')) check(input, formName); });
    });
  });

  /* ---------- password strength meter ---------- */
  const strength = $('#strength'), strengthText = $('#strengthText');
  $('#regPassword').addEventListener('input', (e) => {
    const v = e.target.value;
    const score = (v.length >= 8) + /[A-Z]/.test(v) + /[a-z]/.test(v) + /[0-9]/.test(v);
    strength.dataset.level = v ? score : 0;
    strengthText.textContent = !v ? 'Use upper and lower case letters and a number.' : ['', 'Too weak', 'Getting there', 'Almost there', 'Strong password'][score];
  });

  /* ---------- helpers ---------- */
  function showBanner(el, msg, type = 'error') {
    el.textContent = msg; el.hidden = false;
    el.classList.toggle('success', type === 'success');
  }
  function shake(form) { form.classList.remove('shake'); void form.offsetWidth; form.classList.add('shake'); }
  function busy(btn, on) { btn.classList.toggle('loading', on); btn.disabled = on; }

  async function post(path, body) {
    let res;
    try {
      res = await fetch(API_BASE + path, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
    } catch {
      throw new Error("Can't reach the server. Start Apache and MySQL in XAMPP, then open this page from http://localhost/EventHub/frontend/");
    }
    const data = await res.json().catch(() => ({}));
    return { res, data };
  }

  // Show field-level messages sent back by the backend validator
  function applyServerErrors(form, errors = []) {
    errors.forEach((e) => {
      const input = form.querySelector(`[name="${e.field}"]`);
      if (input) setError(input, e.message.charAt(0).toUpperCase() + e.message.slice(1) + '.');
    });
  }

  /* ---------- LOGIN ---------- */
  views.login.addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.currentTarget, banner = $('#loginBanner'), btn = $('.submit', form);
    banner.hidden = true;
    const ok = $$('input', form).map((i) => check(i, 'login')).every(Boolean);
    if (!ok) return shake(form);

    busy(btn, true);
    try {
      const { res, data } = await post('/login.php', { email: form.email.value.trim(), password: form.password.value });
      if (!res.ok) {
        busy(btn, false);
        // 429 = rate limited (too many attempts); the server message says how long to wait.
        showBanner(banner, data.message || 'Sign in failed. Try again.');
        if (data.errors) applyServerErrors(form, data.errors);
        return shake(form);
      }
      Auth.save(data.token, data.data);   // JWT + basic profile
      btn.classList.remove('loading'); btn.classList.add('done'); btn.querySelector('.label').textContent = 'Signed in';
      setTimeout(() => $('#card').classList.add('leaving'), 350);
      setTimeout(() => location.replace('dashboard.html'), 750);
    } catch (err) {
      busy(btn, false);
      showBanner(banner, err.message);
      shake(form);
    }
  });

  /* ---------- REGISTER ---------- */
  views.register.addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.currentTarget, banner = $('#registerBanner'), btn = $('.submit', form);
    banner.hidden = true;
    const ok = $$('input', form).map((i) => check(i, 'register')).every(Boolean);
    if (!ok) return shake(form);

    busy(btn, true);
    try {
      const body = {
        name: form.name.value.trim(),
        email: form.email.value.trim(),
        password: form.password.value,
        confirm_password: form.password.value,
      };
      const { res, data } = await post('/register.php', body);
      busy(btn, false);
      if (!res.ok) {
        showBanner(banner, data.message || 'Could not create the account.');
        if (data.errors) applyServerErrors(form, data.errors);
        return shake(form);
      }
      // Success: go back to login with the email filled in
      loginEmail.value = body.email; clearBtn.hidden = false;
      form.reset(); strength.dataset.level = 0;
      $$('.field', form).forEach((f) => f.classList.remove('valid', 'invalid'));
      go('login');
      showBanner($('#loginBanner'), 'Account created. Sign in to continue.', 'success');
      $('#loginPassword').focus();
    } catch (err) {
      busy(btn, false);
      showBanner(banner, err.message);
      shake(form);
    }
  });

  /* ---------- notice when redirected here after a session expired ---------- */
  if (new URLSearchParams(location.search).has('expired')) {
    showBanner($('#loginBanner'), 'Your session expired. Please sign in again.');
  }
})();
