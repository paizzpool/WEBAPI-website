// PHP API on the same Apache host (XAMPP).
const API_BASE = '/EventHub/backend/api';
