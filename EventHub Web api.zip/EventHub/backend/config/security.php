<?php
// EventHub security settings: JWT, API keys and rate limits.
// Values can be overridden with environment variables (Apache SetEnv / .env loader).

// ---------- JWT ----------
const JWT_ISSUER = "eventhub";
const JWT_TTL    = 3600;            // token lifetime in seconds (1 hour)

/**
 * Secret used to sign tokens.
 * Priority: EVENTHUB_JWT_SECRET env var -> config/jwt_secret.key (auto-created once).
 * The key file is ignored by git and blocked from the web by config/.htaccess.
 */
function eventhubJwtSecret(): string {
    $env = getenv("EVENTHUB_JWT_SECRET");
    if ($env !== false && strlen($env) >= 32) {
        return $env;
    }

    $file = __DIR__ . "/jwt_secret.key";
    if (!is_file($file)) {
        file_put_contents($file, bin2hex(random_bytes(32)), LOCK_EX);
        @chmod($file, 0600);
    }
    return trim((string) file_get_contents($file));
}

// ---------- API keys ----------
// Sent by third-party / partner clients in the "X-API-Key" header.
// Set EVENTHUB_API_KEYS="key1,key2" in production. The demo key is for local testing only.
function eventhubApiKeys(): array {
    $env = getenv("EVENTHUB_API_KEYS");
    if ($env !== false && trim($env) !== "") {
        return array_values(array_filter(array_map("trim", explode(",", $env))));
    }
    return ["eventhub-demo-key-change-me"];
}

// ---------- Rate limits: [max requests, window in seconds] ----------
const RATE_LIMITS = [
    "login_ip"      => [20, 300],   // every login attempt from one IP
    "login_account" => [5, 300],    // FAILED attempts for one email + IP
    "register_ip"   => [5, 600],    // sign-ups from one IP
    "api"           => [120, 60],   // general API traffic per user (or per IP when anonymous)
];
