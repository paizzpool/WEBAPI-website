<?php
// EventHub pagination, sorting and search helpers.
//
// Query string:  ?page=2&limit=10&sort=name&order=desc&search=aiman

function paginationError(string $message): void {
    http_response_code(400);
    header("Content-Type: application/json; charset=UTF-8");

    if (function_exists("logApiRequest")) {
        logApiRequest(400);
    }

    echo json_encode(["success" => false, "message" => $message]);
    exit;
}

/**
 * Read and validate page / limit / sort / order.
 * $sortable is a whitelist, so the ORDER BY column can never be injected.
 */
function paginationParams(
    array $sortable,
    string $defaultSort,
    string $defaultOrder = "asc",
    int $defaultLimit = 10,
    int $maxLimit = 100
): array {
    $page = 1;
    if (isset($_GET["page"])) {
        $page = filter_var($_GET["page"], FILTER_VALIDATE_INT);
        if ($page === false || $page < 1) {
            paginationError("page must be a positive integer");
        }
    }

    $limit = $defaultLimit;
    if (isset($_GET["limit"])) {
        $limit = filter_var($_GET["limit"], FILTER_VALIDATE_INT);
        if ($limit === false || $limit < 1 || $limit > $maxLimit) {
            paginationError("limit must be between 1 and $maxLimit");
        }
    }

    $sort = $defaultSort;
    if (isset($_GET["sort"])) {
        if (!is_string($_GET["sort"]) || !in_array($_GET["sort"], $sortable, true)) {
            paginationError("sort must be one of: " . implode(", ", $sortable));
        }
        $sort = $_GET["sort"];
    }

    $order = strtolower($defaultOrder);
    if (isset($_GET["order"])) {
        $order = is_string($_GET["order"]) ? strtolower($_GET["order"]) : "";
        if (!in_array($order, ["asc", "desc"], true)) {
            paginationError("order must be asc or desc");
        }
    }

    return [
        "page"   => $page,
        "limit"  => $limit,
        "offset" => ($page - 1) * $limit,
        "sort"   => $sort,
        "order"  => $order,
    ];
}

/** Escape % and _ so a search for "100%" does not become a wildcard. */
function likeEscape(string $value): string {
    return addcslashes($value, "%_\\");
}

/** Read ?search= (string, trimmed, max 100 chars). Returns "" when absent. */
function searchParam(): string {
    if (!isset($_GET["search"])) {
        return "";
    }
    if (!is_string($_GET["search"])) {
        paginationError("Invalid search parameter");
    }
    $value = trim($_GET["search"]);
    return function_exists("mb_substr") ? mb_substr($value, 0, 100) : substr($value, 0, 100);
}

function paginationMeta(array $p, int $total): array {
    $pages = max(1, (int) ceil($total / $p["limit"]));

    return [
        "page"        => $p["page"],
        "limit"       => $p["limit"],
        "total"       => $total,
        "total_pages" => $pages,
        "has_prev"    => $p["page"] > 1,
        "has_next"    => $p["page"] < $pages,
        "sort"        => $p["sort"],
        "order"       => $p["order"],
    ];
}
