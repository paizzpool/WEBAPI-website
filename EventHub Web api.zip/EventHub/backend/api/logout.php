<?php
header("Content-Type: application/json; charset=UTF-8");
header("Cache-Control: no-store");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

require_once __DIR__ . "/api_logger.php";

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(204);
    logApiRequest(204);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Allow: POST, OPTIONS");
    http_response_code(405);
    logApiRequest(405);

    echo json_encode([
        "success" => false,
        "message" => "Method not allowed. Use POST."
    ]);
    exit;
}

require_once __DIR__ . "/jwt.php";

// JWTs are stateless, so "logout" = add this token's ID to a revocation list.
// An expired / invalid token is already useless, so logout still succeeds.
$header = $_SERVER["HTTP_AUTHORIZATION"] ?? $_SERVER["REDIRECT_HTTP_AUTHORIZATION"] ?? "";
if ($header === "" && function_exists("getallheaders")) {
    foreach (getallheaders() as $name => $value) {
        if (strcasecmp($name, "Authorization") === 0) {
            $header = $value;
        }
    }
}

if (preg_match('/^Bearer\s+(\S+)$/i', trim($header), $m)) {
    $result = jwtVerify($m[1]);
    if ($result["ok"]) {
        jwtRevoke((string) $result["payload"]["jti"], (int) $result["payload"]["exp"]);
    }
}

logApiRequest(200);

echo json_encode([
    "success" => true,
    "message" => "Logout successful"
]);
?>
