<?php
// EventHub JWT (HS256) helpers. No external library needed.

require_once __DIR__ . "/../config/security.php";

function b64uEncode(string $data): string {
    return rtrim(strtr(base64_encode($data), "+/", "-_"), "=");
}

function b64uDecode(string $data) {
    $pad = (4 - strlen($data) % 4) % 4;
    return base64_decode(strtr($data, "-_", "+/") . str_repeat("=", $pad), true);
}

function jwtEncode(array $payload): string {
    $header  = b64uEncode(json_encode(["typ" => "JWT", "alg" => "HS256"]));
    $body    = b64uEncode(json_encode($payload, JSON_UNESCAPED_SLASHES));
    $sig     = b64uEncode(hash_hmac("sha256", "$header.$body", eventhubJwtSecret(), true));
    return "$header.$body.$sig";
}

/** Create a signed token for a user row. Returns [token, expires_in, expires_at]. */
function jwtIssue(array $user): array {
    $now = time();
    $exp = $now + JWT_TTL;

    $token = jwtEncode([
        "iss"  => JWT_ISSUER,
        "sub"  => (int) $user["user_id"],
        "role" => $user["role"],
        "iat"  => $now,
        "nbf"  => $now,
        "exp"  => $exp,
        "jti"  => bin2hex(random_bytes(16)),
    ]);

    return [$token, JWT_TTL, $exp];
}

/**
 * Verify signature, algorithm, issuer, time claims and revocation.
 * Returns ["ok" => true, "payload" => [...]] or ["ok" => false, "error" => "..."].
 */
function jwtVerify(string $jwt): array {
    $parts = explode(".", $jwt);
    if (count($parts) !== 3) {
        return ["ok" => false, "error" => "Malformed token"];
    }

    [$h, $p, $s] = $parts;
    $header  = json_decode((string) b64uDecode($h), true);
    $payload = json_decode((string) b64uDecode($p), true);
    $sig     = b64uDecode($s);

    if (!is_array($header) || !is_array($payload) || $sig === false) {
        return ["ok" => false, "error" => "Malformed token"];
    }

    // Reject "alg: none" and anything that is not HS256.
    if (($header["alg"] ?? null) !== "HS256") {
        return ["ok" => false, "error" => "Unsupported token algorithm"];
    }

    $expected = hash_hmac("sha256", "$h.$p", eventhubJwtSecret(), true);
    if (!hash_equals($expected, $sig)) {
        return ["ok" => false, "error" => "Invalid token signature"];
    }

    $now = time();
    if (($payload["iss"] ?? null) !== JWT_ISSUER) {
        return ["ok" => false, "error" => "Invalid token issuer"];
    }
    if (!isset($payload["exp"], $payload["sub"], $payload["role"], $payload["jti"])) {
        return ["ok" => false, "error" => "Incomplete token"];
    }
    if ((int) $payload["exp"] <= $now) {
        return ["ok" => false, "error" => "Token expired. Please login again."];
    }
    if (isset($payload["nbf"]) && (int) $payload["nbf"] > $now + 5) {
        return ["ok" => false, "error" => "Token not valid yet"];
    }
    if (jwtIsRevoked((string) $payload["jti"])) {
        return ["ok" => false, "error" => "Token has been revoked. Please login again."];
    }

    return ["ok" => true, "payload" => $payload];
}

// ---------- Revocation list (used by logout) ----------
function jwtRevocationFile(): string {
    return __DIR__ . "/../data/revoked_tokens.json";
}

function jwtIsRevoked(string $jti): bool {
    $file = jwtRevocationFile();
    if (!is_file($file)) {
        return false;
    }
    $list = json_decode((string) file_get_contents($file), true);
    return is_array($list) && isset($list[$jti]) && $list[$jti] > time();
}

function jwtRevoke(string $jti, int $exp): void {
    $file = jwtRevocationFile();
    $fh = @fopen($file, "c+");
    if (!$fh) {
        error_log("Unable to open token revocation list");
        return;
    }

    flock($fh, LOCK_EX);
    $list = json_decode((string) stream_get_contents($fh), true);
    $list = is_array($list) ? $list : [];

    $now = time();
    foreach ($list as $id => $expiry) {          // drop entries that expired anyway
        if ($expiry <= $now) {
            unset($list[$id]);
        }
    }
    $list[$jti] = $exp;

    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, json_encode($list));
    fflush($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
}
