<?php
// EventHub JWT Authentication & RBAC
//
// Every request may carry:  Authorization: Bearer <jwt>
// When the token is valid, $_SESSION["user_id"] and $_SESSION["role"] are filled in memory
// for this request only (no PHP session / cookie is created), so the existing endpoints
// that read $_SESSION keep working unchanged.

require_once __DIR__ . "/api_logger.php";
require_once __DIR__ . "/jwt.php";
require_once __DIR__ . "/rate_limit.php";

function authFail(int $status, string $message): void {
    http_response_code($status);
    header("Content-Type: application/json; charset=UTF-8");
    header('WWW-Authenticate: Bearer realm="EventHub"');
    logApiRequest($status);

    echo json_encode([
        "success" => false,
        "message" => $message
    ]);
    exit;
}

/** Raw Authorization header (Apache/XAMPP sometimes hides it, so check every place). */
function getAuthorizationHeader(): ?string {
    foreach (["HTTP_AUTHORIZATION", "REDIRECT_HTTP_AUTHORIZATION"] as $key) {
        if (!empty($_SERVER[$key])) {
            return trim($_SERVER[$key]);
        }
    }

    if (function_exists("getallheaders")) {
        foreach (getallheaders() as $name => $value) {
            if (strcasecmp($name, "Authorization") === 0) {
                return trim($value);
            }
        }
    }

    return null;
}

/** Validate the Bearer token (if any) and expose the user to the request. */
function authenticateRequest(): void {
    $GLOBALS["AUTH_PAYLOAD"] = null;

    $header = getAuthorizationHeader();
    if ($header === null || $header === "") {
        return;                                   // anonymous request
    }

    if (!preg_match('/^Bearer\s+(\S+)$/i', $header, $m)) {
        authFail(401, "Authorization header must be: Bearer <token>");
    }

    $result = jwtVerify($m[1]);
    if (!$result["ok"]) {
        authFail(401, $result["error"]);
    }

    $payload = $result["payload"];
    $_SESSION = [
        "user_id" => (int) $payload["sub"],
        "role"    => $payload["role"],
    ];
    $GLOBALS["AUTH_PAYLOAD"] = $payload;
}

function requireLogin() {
    if (!isset($_SESSION["user_id"], $_SESSION["role"])) {
        authFail(401, "Authentication required. Please login.");
    }

    return (int) $_SESSION["user_id"];
}

function requireRole($allowedRoles) {
    requireLogin();

    if (!in_array($_SESSION["role"], $allowedRoles, true)) {
        http_response_code(403);
        logApiRequest(403);

        echo json_encode([
            "success" => false,
            "message" => "Access denied. Insufficient permissions."
        ]);

        exit;
    }
}

// Run on include.
authenticateRequest();

// General API rate limit: per user when signed in, otherwise per IP.
enforceRateLimit(
    "api",
    isset($_SESSION["user_id"]) ? "user:" . $_SESSION["user_id"] : "ip:" . clientIp()
);
?>
