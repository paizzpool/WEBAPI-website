<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key");

require_once __DIR__ . "/api_logger.php";

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(204);
    logApiRequest(204);
    exit;
}

function respond($status, $success, $message, $extra = []) {
    http_response_code($status);
    logApiRequest($status);

    echo json_encode(array_merge([
        "success" => $success,
        "message" => $message
    ], $extra), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    header("Allow: GET, OPTIONS");
    respond(405, false, "Method not allowed");
}

require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/auth.php";

$userId = requireLogin();

try {
    $stmt = $pdo->prepare(
        "SELECT user_id, name, email, role, created_at
         FROM users
         WHERE user_id = ?
         LIMIT 1"
    );
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    if (!$user) {
        $_SESSION = [];
        respond(401, false, "Session user no longer exists. Please login.");
    }

    respond(200, true, "Authenticated", [
        "data" => [
            "user_id" => (int)$user["user_id"],
            "name" => $user["name"],
            "email" => $user["email"],
            "role" => $user["role"],
            "created_at" => $user["created_at"]
        ]
    ]);
} catch (PDOException $e) {
    error_log("Me API error: " . $e->getMessage());
    respond(500, false, "Could not load account");
}
