<?php
header("Content-Type: application/json; charset=UTF-8");
header("Cache-Control: no-store");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

require_once __DIR__ . "/api_logger.php";

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(204);
    logApiRequest(204);
    exit;
}

function respond($status, $success, $message, $extra = []) {
    http_response_code($status);
    logApiRequest($status);

    echo json_encode(array_merge([
        "success" => $success,
        "message" => $message
    ], $extra), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Allow: POST, OPTIONS");
    respond(405, false, "Method not allowed");
}

require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/jwt.php";
require_once __DIR__ . "/rate_limit.php";

// ---- Rate limit 1: every attempt from this IP ----
enforceRateLimit(
    "login_ip",
    clientIp(),
    "Too many login attempts from your network. Please wait and try again."
);

$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data) || array_is_list($data)) {
    respond(400, false, "Valid JSON object is required");
}

$email = $data["email"] ?? null;
$password = $data["password"] ?? null;

if (!is_string($email) ||
    !filter_var($email, FILTER_VALIDATE_EMAIL) ||
    !is_string($password) ||
    $password === "") {
    respond(400, false, "Valid email and password are required");
}

$email = strtolower(trim($email));

// ---- Rate limit 2: failed attempts for this account from this IP ----
$accountKey = $email . "|" . clientIp();
$account = rateLimitPeek("login_account", $accountKey);
if (!$account["allowed"]) {
    rateLimitExceeded(
        $account,
        "Too many failed attempts. Try again in " . ceil($account["retry_after"] / 60) . " minute(s)."
    );
}

try {
    $stmt = $pdo->prepare(
        "SELECT user_id, name, email, password_hash, role
         FROM users
         WHERE email = ?
         LIMIT 1"
    );

    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // Always run password_verify so response time does not reveal whether the email exists.
    $dummyHash = '$2y$10$xPzJtcyQmEemEAh3vZ.0L.Di7aycIIqzpD6JexfP5CkAZtl2QqyTO';
    $valid = password_verify($password, $user ? $user["password_hash"] : $dummyHash);

    if (!$user || !$valid) {
        rateLimitHit("login_account", $accountKey);
        respond(401, false, "Invalid email or password");
    }

    rateLimitClear("login_account", $accountKey);

    [$token, $expiresIn, $expiresAt] = jwtIssue($user);

    respond(200, true, "Login successful", [
        "token" => $token,
        "token_type" => "Bearer",
        "expires_in" => $expiresIn,
        "expires_at" => $expiresAt,
        "data" => [
            "user_id" => (int)$user["user_id"],
            "name" => $user["name"],
            "email" => $user["email"],
            "role" => $user["role"]
        ]
    ]);

} catch (PDOException $e) {
    error_log("Login API error: " . $e->getMessage());
    respond(500, false, "Login failed due to server error");
}
?>
