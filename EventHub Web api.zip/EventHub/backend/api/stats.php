<?php
// Dashboard summary numbers. Role-aware:
//   admin     -> whole platform
//   organiser -> only their own events
//   customer  -> only their own bookings
header("Content-Type: application/json; charset=UTF-8");
header("Cache-Control: no-store");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key");

require_once __DIR__ . "/api_logger.php";

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(204);
    logApiRequest(204);
    exit;
}

function respond($status, $success, $message, $extra = []) {
    http_response_code($status);
    logApiRequest($status);

    echo json_encode(array_merge([
        "success" => $success,
        "message" => $message
    ], $extra), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    header("Allow: GET, OPTIONS");
    respond(405, false, "Method not allowed");
}

require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/auth.php";

$userId = requireLogin();

try {
    $stmt = $pdo->prepare("SELECT role FROM users WHERE user_id = ? LIMIT 1");
    $stmt->execute([$userId]);
    $role = $stmt->fetchColumn();

    if (!$role) {
        respond(401, false, "Account no longer exists. Please login.");
    }

    $one = function (string $sql, array $params = []) use ($pdo) {
        $s = $pdo->prepare($sql);
        $s->execute($params);
        return $s->fetchColumn();
    };
    $all = function (string $sql, array $params = []) use ($pdo) {
        $s = $pdo->prepare($sql);
        $s->execute($params);
        return $s->fetchAll();
    };

    // Which bookings / events is this user allowed to see?
    if ($role === "admin") {
        $bookingScope = "1=1";   $eventScope = "1=1";   $scopeParams = [];
    } elseif ($role === "organiser") {
        $bookingScope = "e.organiser_id = ?";  $eventScope = "e.organiser_id = ?";  $scopeParams = [$userId];
    } else {
        $bookingScope = "b.customer_id = ?";   $eventScope = "1=1";   $scopeParams = [$userId];
    }

    $fromBookings = "FROM bookings b JOIN events e ON e.event_id = b.event_id WHERE $bookingScope";

    $stats = [
        "role"             => $role,
        "bookings_total"   => (int) $one("SELECT COUNT(*) $fromBookings", $scopeParams),
        "tickets_sold"     => (int) $one("SELECT COALESCE(SUM(b.quantity),0) $fromBookings AND b.booking_status = 'confirmed'", $scopeParams),
        "revenue"          => (float) $one("SELECT COALESCE(SUM(b.quantity * e.ticket_price),0) $fromBookings AND b.booking_status = 'confirmed'", $scopeParams),
        "bookings_by_status" => [
            "confirmed" => 0, "pending" => 0, "cancelled" => 0
        ],
    ];

    foreach ($all("SELECT b.booking_status AS s, COUNT(*) AS c $fromBookings GROUP BY b.booking_status", $scopeParams) as $row) {
        $stats["bookings_by_status"][$row["s"]] = (int) $row["c"];
    }

    // Recent bookings (with names so the UI needs no extra lookups)
    $stats["recent_bookings"] = $all(
        "SELECT b.booking_id, b.quantity, b.booking_status, b.booked_at,
                e.event_name, e.ticket_price, u.name AS customer_name
         FROM bookings b
         JOIN events e ON e.event_id = b.event_id
         JOIN users u ON u.user_id = b.customer_id
         WHERE $bookingScope
         ORDER BY b.booked_at DESC, b.booking_id DESC
         LIMIT 5",
        $scopeParams
    );

    if ($role === "customer") {
        // Their next booked (non-cancelled) events
        $stats["upcoming_events"] = $all(
            "SELECT e.event_id, e.event_name, e.event_date, v.venue_name, b.quantity
             FROM bookings b
             JOIN events e ON e.event_id = b.event_id
             JOIN venues v ON v.venue_id = e.venue_id
             WHERE b.customer_id = ? AND b.booking_status <> 'cancelled' AND e.event_date >= NOW()
             ORDER BY e.event_date ASC
             LIMIT 5",
            [$userId]
        );
        $stats["events_total"] = (int) $one("SELECT COUNT(*) FROM events WHERE event_date >= NOW()");
    } else {
        $stats["events_total"]    = (int) $one("SELECT COUNT(*) FROM events e WHERE $eventScope", $role === "organiser" ? [$userId] : []);
        $stats["events_upcoming"] = (int) $one("SELECT COUNT(*) FROM events e WHERE $eventScope AND e.event_date >= NOW()", $role === "organiser" ? [$userId] : []);

        $stats["top_events"] = $all(
            "SELECT e.event_id, e.event_name, e.total_tickets,
                    (e.total_tickets - e.tickets_available) AS tickets_booked
             FROM events e
             WHERE $eventScope
             ORDER BY (e.total_tickets - e.tickets_available) DESC, e.event_id ASC
             LIMIT 5",
            $role === "organiser" ? [$userId] : []
        );

        $stats["upcoming_events"] = $all(
            "SELECT e.event_id, e.event_name, e.event_date, v.venue_name,
                    e.tickets_available, e.total_tickets
             FROM events e
             JOIN venues v ON v.venue_id = e.venue_id
             WHERE $eventScope AND e.event_date >= NOW()
             ORDER BY e.event_date ASC
             LIMIT 5",
            $role === "organiser" ? [$userId] : []
        );

        $avg = $one(
            "SELECT AVG(r.rating) FROM reviews r JOIN events e ON e.event_id = r.event_id WHERE $eventScope",
            $role === "organiser" ? [$userId] : []
        );
        $stats["average_rating"] = $avg === null ? null : round((float) $avg, 2);
    }

    if ($role === "admin") {
        $stats["users_total"]  = (int) $one("SELECT COUNT(*) FROM users");
        $stats["venues_total"] = (int) $one("SELECT COUNT(*) FROM venues");
    }

    respond(200, true, "Stats retrieved", ["data" => $stats]);

} catch (PDOException $e) {
    error_log("Stats API error: " . $e->getMessage());
    respond(500, false, "Could not load dashboard stats");
}
