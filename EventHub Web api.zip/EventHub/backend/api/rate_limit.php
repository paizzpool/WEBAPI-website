<?php
// EventHub file-based rate limiter (fixed window). Works on plain XAMPP, no extensions needed.

require_once __DIR__ . "/../config/security.php";

function clientIp(): string {
    // REMOTE_ADDR only: X-Forwarded-For can be forged by the client.
    return $_SERVER["REMOTE_ADDR"] ?? "unknown";
}

function rateLimitFile(string $bucket, string $key): string {
    $dir = __DIR__ . "/../data/rate_limit";
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    return $dir . "/" . hash("sha256", $bucket . "|" . $key) . ".json";
}

/** Read current state without counting a hit. */
function rateLimitPeek(string $bucket, string $key): array {
    [$max, $window] = RATE_LIMITS[$bucket];
    $file = rateLimitFile($bucket, $key);
    $state = is_file($file) ? json_decode((string) file_get_contents($file), true) : null;
    $now = time();

    if (!is_array($state) || ($state["reset"] ?? 0) <= $now) {
        $state = ["count" => 0, "reset" => $now + $window];
    }

    return [
        "allowed"     => $state["count"] < $max,
        "limit"       => $max,
        "remaining"   => max(0, $max - $state["count"]),
        "retry_after" => max(1, $state["reset"] - $now),
    ];
}

/** Count one hit and return the new state. */
function rateLimitHit(string $bucket, string $key): array {
    [$max, $window] = RATE_LIMITS[$bucket];
    $fh = @fopen(rateLimitFile($bucket, $key), "c+");
    if (!$fh) {
        // Never lock everyone out because the data folder is not writable.
        return ["allowed" => true, "limit" => $max, "remaining" => $max, "retry_after" => 0];
    }

    flock($fh, LOCK_EX);
    $state = json_decode((string) stream_get_contents($fh), true);
    $now = time();

    if (!is_array($state) || ($state["reset"] ?? 0) <= $now) {
        $state = ["count" => 0, "reset" => $now + $window];
    }
    $state["count"]++;

    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, json_encode($state));
    fflush($fh);
    flock($fh, LOCK_UN);
    fclose($fh);

    // Occasional housekeeping of stale counters.
    if (random_int(1, 200) === 1) {
        foreach (glob(dirname(rateLimitFile($bucket, $key)) . "/*.json") ?: [] as $f) {
            if (filemtime($f) < $now - 86400) {
                @unlink($f);
            }
        }
    }

    return [
        "allowed"     => $state["count"] <= $max,
        "limit"       => $max,
        "remaining"   => max(0, $max - $state["count"]),
        "retry_after" => max(1, $state["reset"] - $now),
    ];
}

function rateLimitClear(string $bucket, string $key): void {
    @unlink(rateLimitFile($bucket, $key));
}

/** Send X-RateLimit headers. */
function rateLimitHeaders(array $state): void {
    header("X-RateLimit-Limit: " . $state["limit"]);
    header("X-RateLimit-Remaining: " . $state["remaining"]);
}

/** Stop the request with HTTP 429. */
function rateLimitExceeded(array $state, string $message = "Too many requests. Please slow down."): void {
    http_response_code(429);
    header("Content-Type: application/json; charset=UTF-8");
    header("Retry-After: " . $state["retry_after"]);
    rateLimitHeaders($state);

    if (function_exists("logApiRequest")) {
        logApiRequest(429);
    }

    echo json_encode([
        "success"     => false,
        "message"     => $message,
        "retry_after" => $state["retry_after"],
    ]);
    exit;
}

/** Count a hit and stop with 429 if the bucket is over its limit. */
function enforceRateLimit(string $bucket, string $key, ?string $message = null): void {
    $state = rateLimitHit($bucket, $key);
    rateLimitHeaders($state);
    if (!$state["allowed"]) {
        rateLimitExceeded($state, $message ?? "Too many requests. Please slow down.");
    }
}
