<?php
// EventHub API key protection.
//
// Public read endpoints (events, venues, reviews, venue location) are no longer open to
// anonymous traffic. A request must carry EITHER
//   - a valid JWT        (the EventHub dashboard / logged-in users), or
//   - a valid API key    (partner apps, scripts):  X-API-Key: <key>

require_once __DIR__ . "/auth.php";

function requestApiKey(): ?string {
    if (!empty($_SERVER["HTTP_X_API_KEY"])) {
        return trim($_SERVER["HTTP_X_API_KEY"]);
    }

    if (function_exists("getallheaders")) {
        foreach (getallheaders() as $name => $value) {
            if (strcasecmp($name, "X-API-Key") === 0) {
                return trim($value);
            }
        }
    }

    return null;   // header only: keys in URLs end up in logs and browser history
}

function apiKeyIsValid(): bool {
    $sent = requestApiKey();
    if ($sent === null || $sent === "") {
        return false;
    }

    foreach (eventhubApiKeys() as $key) {
        if (hash_equals($key, $sent)) {
            return true;
        }
    }

    return false;
}

function requireJwtOrApiKey(): void {
    if (isset($_SESSION["user_id"])) {
        return;                                    // already authenticated by JWT
    }

    if (requestApiKey() === null) {
        authFail(401, "API key or Bearer token required. Send an X-API-Key header or login.");
    }

    if (!apiKeyIsValid()) {
        http_response_code(403);
        logApiRequest(403);
        echo json_encode(["success" => false, "message" => "Invalid API key."]);
        exit;
    }
}
